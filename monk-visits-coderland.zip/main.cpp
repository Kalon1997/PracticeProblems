/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*

#include<bits/stdc++.h>
using namespace std;
 
typedef long long ll;
 
int main(){
    int test;
    cin >> test;
    while(test--){
        ll n,pos,sum=0;
        ll ans = 0;
        ll mn;
        scanf("%lld",&n);
        ll c[n+5],l[n+5];
        for(int i=0;i<n;i++) scanf("%lld",&c[i]);
        for(int i=0;i<n;i++) scanf("%lld",&l[i]);
        ans+=c[0]*l[0];
        mn = c[0];
        for(int i=1;i<n;i++){
            mn = min(mn,c[i]);
            ans+=mn*l[i];
          
        }
        cout << ans << endl;
    }
 
    return 0;
}

*/



#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 1000

int indexOf(int val, int l[MAX_SIZE], int n)
{
    int r;
    for(int i=0;i<n;i++)
    {
        if(val == l[i])
            r=i;
    }
    return r;
}


int find_min(int C[MAX_SIZE], int N)
{
    int min = C[0];
    for(int i=1;i<N;i++)
    {
        if(C[i]<min)
            min=C[i];
    }
    return min;
}

void func(int c[MAX_SIZE], int l[MAX_SIZE], int n)
{
    int ans;
    int s;
    int res;
    int k;
    k=ans=find_min(c,n);
    
    l1: if(ans==c[0])
        {
            for(int i=0;i<n;i++)
            {
                s+=l[i];
                res=ans*s;
            }
            return;
                
        }
    else
    {
        ans=find_min(c,indexOf(k,c,n)+1);
        goto l1;
    }
    cout<<res;
}


int main()
{
    int T;
    cin>>T;
    int N;
    int C[MAX_SIZE];
    int L[MAX_SIZE];
    while(T--)
    {
        cin>>N;
        for(int i=0;i<N;i++)
            cin>>C[i];
        for(int i=0;i<N;i++)
            cin>>L[i];
            
    func(C,L,N);        
    }
    
    return 0;
}
