/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <bits/stdc++.h>
#include <iostream>
#include <vector>
using namespace std;

vector<string> v;

int main()
{
    string str="my.name.is.kalon";
   // cout<<"enter string ";
    // cin>>str;
    for(int i=0;i<str.size();i++)
    {
        if(str[i]=='.')
            str[i]=' ';
    }
    
    string word;
    stringstream iss(str);
    
    while(iss>>word)
    v.push_back(word);
    
    reverse(v.begin(), v.end());
    
    for(int i; i<v.size(); i++)
    {
        cout << v[i] << " ";
    }
    
    return 0;
}
