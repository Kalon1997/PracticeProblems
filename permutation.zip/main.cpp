/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using namespace std;
#include <bits/stdc++.h>
string s1[600];
int p;
void bac(string s,int i,int n)
{
    if(i==n-1)
    {
        //cout<<s<<" ";
        s1[p]=s;
        p++;
    }
    else
    {
        for(int j=i; j<n; j++)
        {
            swap(s[i],s[j]);
            bac(s,i+1,n);
            swap(s[i],s[j]);
        }
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        string s;
        cin>>s;
        int n=s.size();
        sort(s.begin(),s.end());
        p=0;
        bac(s,0,n);
        sort(s1,s1+p);
        for(int i=0; i<p; i++)
        {
            cout<<s1[i]<<" ";
        }
        cout<<endl;
    }
}