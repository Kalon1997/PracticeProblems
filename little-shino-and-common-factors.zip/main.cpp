/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<bits/stdc++.h>
using namespace std;
long long int get_min(long long int x,long long int y)
{
    if(x<=y)
      return x;
    else
      return y;
    
}

int main()
{
    long long int a, b;
    int c=0;
    cin>>a>>b;
    long long int m=get_min(a,b);
    for(long long int i=1;i<=m/2;i++)
    {
        if((a%i == 0) && (b%i == 0))
        c++;
    }
    if(a%b==0 || b%a==0)
        cout<<c+1;
    else 
        cout<<c;
    return 0;
}