/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*#include <bits/stdc++.h>
#include <stdio.h>
#define MAX_SIZE 100000

bool sortBylogic(const pair<int,int> &a, const pair<int,int> &b)
{
        if(a.first!=b.first)
        return(a.first < b.first); 
        else
        return(a.second > b.second);
}



int main()
{
    int T;  //test casses
    int n;
    vector< pair <int,int> > pts;  //both x and y coordinates of the point will be stored here as pairs
    int inX[MAX_SIZE], inY[MAX_SIZE];
    
    //cin>>T;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        pts.push_back(make_pair(inX[i],inY[i]));
    }
    //now sorting
    
    sort(pts.begin(),pts.end(),sortBylogic);
    for (int i=0; i<n; i++) 
    { 
        // "first" and "second" are used to access 
        // 1st and 2nd element of pair respectively 
        cout << pts[i].first << " "
             << pts[i].second << endl; 
    }
    
    
}
*/









#include <bits/stdc++.h>
#include <stdio.h>


bool sortBylogic(const pair<int,int> &a, const pair<int,int> &b)
{
        
        return(a.first < b.first); 
        
        
}



int main()
{
  
    //{4,3},{2,1},{2,6},{3,0}  =>   2,6     2,1    3,0       4,3
    vector< pair <int,int> > pts;  //both x and y coordinates of the point will be stored here as pairs
    int inX[]={4,2,2,3};
    int inY[]={3,1,6,0};
    
    
    
    for(int i=0;i<n;i++)
    {
        pts.push_back(make_pair(inX[i],inY[i]));
    }
    //now sorting
    
    sort(pts.begin(),pts.end(),sortBylogic);
    for (int i=0; i<n; i++) 
    { 
    
        cout << pts[i].first << " "<< pts[i].second << endl;
              
    }
    
    
}
