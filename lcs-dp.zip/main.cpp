/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 1000
int maxx(int x,int y)
{
    if(x>=y)
        return x;
    else
        return y;
}        

void LCS_DP(string str1, string str2)
{
    int n1 = str1.length();
    int n2 = str2.length();
    int LCS[MAX_SIZE][MAX_SIZE];
    for(int i=0;i<1;i++)
    {
        for(int j=0;j<1;j++)
        {
            LCS[i][j] = 0;
            LCS[j][i] = 0;
        }
    }
    for(int i=1;i<n1;i++)
    {
        for(int j=1;j<n2;j++)
        {
            if(str1[n1-1]==str2[n2-1])
            {
                LCS[i][j]=(LCS[i-1][j-1]+1);
            }
            if(str1[n1-1]!=str2[n2-1])
            {
                LCS[i][j] = maxx(LCS[i-1][j],LCS[i][j-1]);
            }
        }
    }
    cout<<LCS[n1-1][n2-1];
}

int main()
{
    string s1;
    string s2;
    cin>>s1;
    cin>>s2;
    LCS_DP(s1,s2);

    return 0;
}
