/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<bits/stdc++.h>
#define MAX_SIZE 100
using namespace std;

bool sorting_it(const pair<string,int> &a, const pair<string,int> &b ) {
    
    
    if(a.second!=b.second)
        return (a.second>b.second);
    else
        return(a.first<b.first);
    
}

int main()
{
    int N;
    int T;
    cin>>N>>T;
    string str;
    int q;
    pair<string,int> p[MAX_SIZE];
    for(int i=0;i<N;i++)
    {
        cin>>str>>q;
        p[i]=make_pair(str,q);
    }
    sort(p,p+N,sorting_it);
    for(int i=0;i<T;i++)
    {
       cout<<p[i].first<<endl;
      
    }
    return 0;
}

