#include <bits/stdc++.h>
using namespace std;
 
vector<int>v[100001];
int vis[100001] = {};
 
 
 
void dfs(int x){
 
    vis[x] = 1;
    for(int i = 0;i<v[x].size();i++){
        if(vis[v[x][i]] != 1)
            dfs(v[x][i]);
    }
}
 
int main () {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
  
    int n,m,k;
    cin >> n >> m >> k;
    
    int x,y;
    for(int i=0;i<m;i++){
        cin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    if(m < n-k){
        cout << -1 <<"\n";
    }else{
        int count = 0;
        for(int i=1;i<=n;i++){
            
            if(vis[i] != 1){
                dfs(i);
                count++;
            }
        }
        
        if(count > k)
            cout << -1 <<"\n";
        else    
            cout << m-n+k <<"\n";
    }
   
        
    return 0;
}
Language: C++14