/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <bits/stdc++.h>
#define MAX_SIZE 10000
using namespace std;



int if_palin(string str)
{
     int l=0;
     int h=str.length()-1;
   
            while(l<h)
           {
               if(str[l++]!=str[h--])
                  //cout<<"noooo  ";
                  return -1;
              
             
           }
   
     return 1;
   
    
}



long func(string s, long n)
{
    string temp;
    string a[100];
    long k=0;
    long c=0;
    int ans;
    for (int i = 0; i < n; i++)
    {
        for (int len = 1; len <= n - i; len++) 
        {
            
           temp=s.substr(i, len);
           ans=if_palin(temp);
           if(ans==1)
                c=c+1;
           
            
          
            
        }
       
    }
    
     return c;
    
}

int main()
{
   string str;
   cin>>str;
  // long ans,n;
  long n;
   n=str.length();
   //func(str,n);
   //ans=func(str,n);
  // cout<<ans;
  long op;
  op=func(str,n);
  cout<<op<<endl;
  
    return 0;
}



