/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 1000
 
int getIndexOfMaxElement(int a[MAX_SIZE], int n)
{
   // int n = sizeof(a)/sizeof(a[0]);
    int ans;
    int maxx=a[0];
    for(int i=1;i<n;i++)
    {
        if(a[i]>maxx)
        {
            maxx=a[i];
            ans=i;
        }
    }
    return ans;
}
 
int hamming_dist(string s1, string s2)
{
    int m = s1.length();
    int c=0;
    for(int i=0;i<m;i++)
    {
        if(s1[i]!=s2[i])
        c++;
    }
    return c;
}
 
 
int main()
{
    int N, M;
    cin>>N>>M;
    int T[MAX_SIZE][MAX_SIZE];
    int sum[MAX_SIZE];
    memset(sum,0,sizeof(sum));
    string arr[MAX_SIZE];
    for(int i=0;i<N;i++)
    {
        cin>>arr[i];
    }
    
    for(int i=0;i<N;i++)
    {
        for(int j=0;j<N;j++)
        {
            if(i<j)
                {
                    int hum = hamming_dist(arr[i],arr[j]);
                    T[i][j]=hum;
                    T[j][i]=hum;
                    
                } 
            
            if(i==j)
                T[i][j]=0;
        }
        
    }
    
    for(int i=0;i<N;i++)
    {
        for(int j=0;j<N;j++)
        {
            sum[i]+=T[i][j];
        }
    }
    int yess = getIndexOfMaxElement(sum,M);
    cout<<arr[yess];
    
    
    return 0;
}
