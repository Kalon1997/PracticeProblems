/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <bits/stdc++.h>
using namespace std;
int N;
pair<int, int> A[100000];
int main()
{
    scanf("%d", &N);
    for(int i=0; i<N; i++)
        scanf("%d", &A[i].first), A[i].second=i;
    sort(A, A+N, greater<pair<int, int>>());
    int a=A[0].second, b=A[0].second;
    int ans=0;
    for(int i=1; i<N; i++)
    {
        int x=A[i].second;
        if(x<a || x>b)
            ans++;
        else
            ans+=2;
        a=min(a, x);
        b=max(b, x);
    }
    printf("%d\n", ans);
    return 0;
}