/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<bits/stdc++.h>
using namespace std;

 double get_the_ones(string str)
 {
     double c=0;
    for(long i=0;i<str.length();i++) 
    {
        if(str[i]=='1')
        c++;
    }
    return c;
 }     

int main()
{
    double arr_yes[7];
    long k=0;
    double sum=0.0;
    string str;
    int t=7;
    while(t--)
    {
        cin>>str;
        arr_yes[k]=get_the_ones(str);
        sum+=arr_yes[k];
        k++;
    }
    
    
    double x_bar;
    x_bar = sum/7;
    
    double numerator=0.0;
    for(long i=0;i<7;i++)
    {
       
        numerator+=((arr_yes[i] - x_bar) * (arr_yes[i] - x_bar));
    }
    double sigma;
    sigma= sqrt(numerator/7);
    cout<<" "<<sigma;
    
    
    //cout<<sum;
    
    
}
