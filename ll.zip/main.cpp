/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
struct node
{
    int data;
    node *link;
};

 node *head=NULL;
void insert_front(int d)
{
    node *new_node = new node();
    new_node->data=d;
    
    
    
    
        new_node->link=head;
        head=new_node;
    
    
}

void display()
{
    node *temp = new node();
    temp=head;
   // if(head==NULL)
    //{
      //  cout<<" Nothing to diaplay ";
    //}
    //else
    {
        while(temp!=NULL)
        {
            cout<<temp->data;
            temp=temp->link;
        }
    }
}

int main()
{
    cout<<"L I N K E D   L I S T"<<endl;
   
    insert_front(5);
    insert_front(4);
    insert_front(3);
    insert_front(2);
    insert_front(1);
    
    display();

    return 0;
}

