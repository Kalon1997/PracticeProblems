/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include<bits/stdc++.h>
using namespace std;



void func(string str, int a, int b)
{
    
    char temp;
    int n=b+2;
    for(int i=a;i<n-1;i++)
    {
        for(int j=a;j<n-i-1;j++)
        {
            if(str[j]<str[j+1])
            {
                temp = str[j+1];
                str[j+1] = str[j];
                str[j] = temp;
            }
        }
    }
   
   
    cout<<str<<endl;
}


int main()
{
    int T;
    string str;
    cin>>T;
    int x,y;
    while(T--)
    {
        cin>>str>>x>>y;
        func(str,x,y);
    }
}
