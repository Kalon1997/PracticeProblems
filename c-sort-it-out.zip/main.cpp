/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 10000

bool sortByFirst_inc(const pair<int,int> &a, const pair<int,int> &b)
{
    return (a.first<b.first);
}

int main()
{
    int arr[MAX_SIZE];
    pair<int,int> p[MAX_SIZE];
    int n;
    //vector<int,int> v[MAX_SIZE];
    cin>>n;
    int k=0;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
        p[k++]=make_pair(arr[i],i);
        
    }
    sort(p,p+n,sortByFirst_inc);
    
    for(int i=0;i<n;i++)
    {
        cout<<p[i].second<<" ";
          
    }
    
  

    return 0;
}

