/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

/*
#include<bits/stdc++.h>
using namespace std;
int main(void)
{
    int t,i,j,n;
    string s;
    cin>>t;
    vector<int>vec;
    for(i=65;i<=90;i++)
    {
            int x=0;
            for(j=1;j<=i;j++)
            {
                if(i%j==0)
                x++;
            }
            if(x==2)
            vec.push_back(i);
    }
    for(i=97;i<=122;i++)
    {
            int x=0;
            for(j=1;j<=i;j++)
            {
                if(i%j==0)
                x++;
            }
            if(x==2)
            vec.push_back(i);
    }
    while(t--)
    {
        cin>>n>>s;
        for(i=0;i<n;i++)
        {
            int mi=INT_MAX,mii=INT_MAX;
            for(j=0;j<vec.size();j++)
            {
                if(abs(vec[j]-s[i])<mii)
                {
                    mi=vec[j];
                    mii=abs(vec[j]-s[i]);
                }
                else if(abs(vec[j]-s[i])==mii)
                {
                    if(vec[j]<mi)
                    mi=vec[j];
                }
            }
            cout<<(char)mi;
        }
        cout<<endl;
    }
}







#include<bits/stdc++.h>
using namespace std;
int main()
{ int arr[]={67,71,73,79,83,89,97,101,103,107,109,113};
int T,N;
string s;
cin>>T;
while(T--)
{int pos=0,d=0,e;
cin>>N>>s;
for(int i=0;i<s.length();i++)
{
    { 
        d=abs(s[i]-arr[0]);
        pos=0;
        for(int j=1;j<12;j++)
        {
            e=abs(arr[j]-s[i]);
            if(e<d)
            {
                d=e;
                pos=j;
            }
        }
        printf("%c",arr[pos]);
    }
}
printf("\n");
}
 
}

*/










#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 100



int main()
{
   
   
vector<int> vec;
for(int i=65;i<=90;i++)
{
    for(int j=2;j<(i/2)+1;j++)
    {
        if(i%j!=0)
        vec.push_back(i);
    }
}
for(int i=97;i<=122;i++)
{
    for(int j=2;j<(i/2)+1;j++)
    {
        if(i%j!=0)
        vec.push_back(i);
    }
}

for(auto i=vec.begin();i!=vec.end();++i)
{
    cout<<*i<<" ";
}
    return 0;
}


/*
vector<int> g1; 
  
    for (int i = 1; i <= 5; i++) 
        g1.push_back(i); 
  
    cout << "Output of begin and end: "; 
    for (auto i = g1.begin(); i != g1.end(); ++i) 
        cout << *i << " "; 
        
        

}
*/

