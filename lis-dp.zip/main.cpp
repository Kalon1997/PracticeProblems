/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using namespace std;
#define MAX_SIZE 10000
void LIS(int a[MAX_SIZE], int n)
{
    int temp;
    int LIS[MAX_SIZE];
    for(int i=0;i<n;i++)
    {
        LIS[i]=1;
    }
    
    for(int i=1;i<n;i++)
    {
        for(int j=0;j<i;j++)
        {
            if(a[j]<a[i])
            {
                temp = LIS[j] + 1;
                if(temp >= LIS[i])
                    LIS[i] = LIS[j] + 1;
            }    
        }
    }
    cout<<LIS[n-1];
    
    
}

int main()
{
    int n;
    int a[MAX_SIZE];
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    LIS(a,n);
    return 0;
}
